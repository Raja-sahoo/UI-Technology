/*
var app = angular.module('firstApp', []);
app.controller('firstCont', function($scope){
$scope.items = []; 

$scope.then = function(data){
$scope.items.push(data);
}
});
*/
var app = angular.module("simpleapp",[]);
app.controller("simpleController", function($scope){
	$scope.collection = [{name:"Raja" ,age:"23" , city:"new York"},
		{name:"Renchu" , age:"22", city:"London"}
	];
	$scope.addEntry = function(){
		$scope.collection.push($scope.newData);
		$scope.newData = "";
	};
});


